<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//User
Route::get('/lists', 'Admin\EmployeController@index')->name('lists');
Route::post('/listingEmployee','Admin\EmployeController@listingEmployee');
Route::get('/add', 'Admin\EmployeController@add')->name('add');
Route::post('/add', 'Admin\EmployeController@insert')->name('add');
Route::get('/edit/{id}', 'Admin\EmployeController@edit')->name('edit');
//Route::post('/edit/{id}', 'Admin\EmployeController@update')->name('edit');
Route::post('/update-data', 'Admin\EmployeController@updateData')->name('edit');

Route::post('/delete_rmployee', 'Admin\EmployeController@deletedata')->name('delete');
