@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
		<div class="col-md-8 col-md-offset-2">
			
			<form method="POST" novalidate>
				 {{ csrf_field() }}

				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<h5> Name <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="name" id="name" value="{{ old('name') }}" required required data-validation-required-message="This field is required"> </div>
							@if ($errors->has('name'))
							<span class="validation" style="color:red;">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
							@endif
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5>User Email <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="email" name="email" id="email" class="form-control" value="{{ old('email') }}" data-validation-required-message="This field is required" required> </div>
							@if ($errors->has('email'))
							<span class="validation" style="color:red;">
								<strong>{{ $errors->first('email') }}</strong>
							</span>
							@endif
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5>Password <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="password" name="password" id="password"  class="form-control" required data-validation-required-message="This field is required"> </div>
							@if ($errors->has('password'))
							<strong><span class="validation" style="color:red;">
							{{ $errors->first('password') }}</strong>
							</span>
							@endif
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5>Repeat Password <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="password" name="psw-repeat" id="psw-repeat" data-validation-match-match="password" class="form-control" required> </div>
							@if ($errors->has('psw-repeat'))
							<span class="validation" style="color:red;">
								<strong>{{ $errors->first('psw-repeat') }}</strong>
							</span>
							@endif
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<h5>Mobile Number <span class="text-danger">*</span></h5>
							<div class="controls">
								<div class="input-group">
								<input type="text" class="form-control" name="mobile_number" id="mobile_number" placeholder="" value="{{ old('mobile_number') }}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10"  required data-validation-required-message="This field is required"></div>
								@if ($errors->has('mobile_number'))
								<span class="validation" style="color:red;">
									<strong>{{ $errors->first('mobile_number') }}</strong>
								</span>
								@endif
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5> Country <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="country" id="country" value="{{ old('country') }}" required required data-validation-required-message="This field is required"> </div>
							@if ($errors->has('country'))
							<span class="validation" style="color:red;">
								<strong>{{ $errors->first('country') }}</strong>
							</span>
							@endif
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5> State <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="state" id="state" value="{{ old('state') }}" required required data-validation-required-message="This field is required"> </div>
							@if ($errors->has('state'))
							<span class="validation" style="color:red;">
								<strong>{{ $errors->first('state') }}</strong>
							</span>
							@endif
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<h5> City <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="city" id="city" value="{{ old('city') }}" required required data-validation-required-message="This field is required"> </div>
							@if ($errors->has('city'))
							<span class="validation" style="color:red;">
								<strong>{{ $errors->first('city') }}</strong>
							</span>
							@endif
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<h5> Birth Date <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="date"  class="form-control" name="birth_date" id="birth_date" value="{{ old('birth_date') }}" required required data-validation-required-message="This field is required"> </div>
							@if ($errors->has('birth_date'))
							<span class="validation" style="color:red;">
								<strong>{{ $errors->first('birth_date') }}</strong>
							</span>
							@endif
						</div>
					</div>
					
				</div>
				<div class="text-xs-right">
					<button type="submit" class="btn btn-info">Submit</button>
					<a href="javascript:history.go(-1)" class="btn btn-default">Cancel</a>
				</div>
			</form>						
			
		</div>
	</div>
	<!-- /.content -->
</div>
@endsection