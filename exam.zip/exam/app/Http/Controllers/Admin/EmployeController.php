<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use Auth;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Collection;
use Mail;
use App\Employee;

class EmployeController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}
	
	public function index()
	{
		return view('admin.employee.list');
	}
	
	public function listingEmployee(Request $request)
	{	
		$columns = array( 
			0=>'id',
			1=>'name',
			2=>'email',
			3=>'mobile_number',
			4=>'country',
			5=>'state',
			6=>'city',
			7=>'birth_date',
			8=>'action',
		);
		
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
		
		$user_id = Auth::user()->id;
		
		$totalData = Employee::where('user_id',$user_id)->count();
		$totalFiltered = Employee::where('user_id',$user_id);
		
		$values = Employee::where('user_id',$user_id)->offset($start)->limit($limit)->orderBy('employees'.'.'.$order,$dir);
		
		if(!empty($request->input('search')))
        {
			$values = $values->where('name', 'LIKE',"%{$request->input('search')}%")->orWhere('email', 'LIKE',"%{$request->input('search')}%")->orWhere('mobile_number', 'LIKE',"%{$request->input('search')}%")->orWhere('country', 'LIKE',"%{$request->input('search')}%")->orWhere('state', 'LIKE',"%{$request->input('search')}%");
			
            $totalFiltered = $totalFiltered->where('name', 'LIKE',"%{$request->input('search')}%")->orWhere('email', 'LIKE',"%{$request->input('search')}%")->orWhere('mobile_number', 'LIKE',"%{$request->input('search')}%")->orWhere('country', 'LIKE',"%{$request->input('search')}%")->orWhere('state', 'LIKE',"%{$request->input('search')}%");
        }
	
		if(!empty($request->input('from_date')) && !empty($request->input('to_date')))
        {
			$from_date = $request->input('from_date');
			$to_date = $request->input('to_date');
			
			$values = $values->where('birth_date', '>=', $from_date)->where('birth_date', '<=', $to_date);
			
			$totalFiltered = $totalFiltered->where('birth_date', '>=', $from_date)->where('birth_date', '<=', $to_date);
		}
		
		$values = $values->get();

		$totalFiltered = $totalFiltered->count();
		
        $data = array();
        if(!empty($values))
        {
            foreach ($values as $value)
            {
				$edit =  url('edit',$value->id);
                $delete =  url('delete',$value->id);
				
				$taskData['name'] = $value->name;
				$taskData['email'] = $value->email;
				$taskData['mobile_number'] = $value->mobile_number;
				$taskData['country'] = $value->country;
				$taskData['state'] = $value->state;
				$taskData['city'] = $value->city;
				$taskData['birth_date'] = $value->birth_date;
				$taskData['action'] = "<a href='{$edit}' style='cursor: pointer;' rel='tooltip' data-toggle='tooltip' data-trigger='hover' data-html='true' data-title='Edit' class='mr-3'><i class='fa fa-pencil aria-hidden='true' text-primary'></i>Edit</a>
                &emsp;<button   style='cursor: pointer;' onClick='return confirm_click($value->id);' rel='tooltip' data-toggle='tooltip' data-trigger='hover' data-html='true' data-title='Delete' class='mr-3' ><i class='fa fa-trash' aria-hidden='true' text-danger></i>Delete</button>";
                $data[] = $taskData;
            }
        }
		
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data
                    );
            
        echo json_encode($json_data); 
	}
	
	public function add(Request $request)
	{
		return view('admin.employee.add');
	}
	
	public function insert(Request $request)
	{
		$messages = array(
			'name.required' => 'This field is required.',
			'email.required' => 'This field is required.',
			'password.required' => 'This field is required.',
			'psw-repeat.required' => 'This field is required.',
			'mobile_number.required' => 'This field is required.',
			'country.required' => 'This field is required.',
			'state.required' => 'This field is required.',
			'city.required' => 'This field is required.',
			'birth_date.required' => 'This field is required.',
		);
		$validation = Validator::make($request->all(), [
			'name' => 'required',
			'email' => 'required|unique:employees',
			'password' => 'required',
			'psw-repeat' => 'required_with:password|same:password',
			'mobile_number' => 'required|unique:employees',
			'country' => 'required',
			'state' => 'required',
			'city' => 'required',
			'birth_date' => 'required',
		], $messages);
		
		if ($validation->fails()) 
		{
			return Redirect::route('add')
			->withInput()
			->withErrors($validation)
			->with('message', 'There were validation errors.');
		}
		else
		{		
			$user_id = Auth::user()->id;
			
			$data = array([
			'name' => $request->input('name'),
			'email' => $request->input('email'),
			'password' => Hash::make($request->input('password')),
			'mobile_number' => $request->input('mobile_number'),
			'country' => $request->input('country'),
			'state' => $request->input('state'),
			'city' => $request->input('city'),
			'birth_date' => $request->input('birth_date'),
			'user_id' => $user_id,
			'created_at' => date('Y-m-d H:i:s'),
			'updated_at' => date('Y-m-d H:i:s'),
			]);
			
			Employee::insert($data);
			
			session()->flash('successmsg','Employee Created Successfully.');
			return Redirect::route('lists');
		}
	}
	
	public function edit($id)
	{
		$get_employee = Employee::where('id', $id)->first();
		
		return view('admin.employee.edit')->with('get_employee' , $get_employee);
	}

	public function deletedata(Request $request)
	{
		$id = $request->input('id');
		
		Employee::where('id', $id)->delete();
		
		session()->flash('successmsg','Employee Delete Successfully.');
		return Redirect::route('lists');
	}
	
	public function updateData(Request $request)
	{
		$employee_id = $request->input('employee_id');
		
		$messages = array(
			'name.required' => 'This field is required.',
			'email.required' => 'This field is required.',
			'mobile_number.required' => 'This field is required.',
			'country.required' => 'This field is required.',
			'state.required' => 'This field is required.',
			'city.required' => 'This field is required.',
			'birth_date.required' => 'This field is required.',
		);
		$validation = Validator::make($request->all(), [
			'name' => 'required',
			'email'=>"required|email|unique:employees,email,$employee_id,id",
			'mobile_number'=>"required|unique:employees,mobile_number,$employee_id,id",
			'country' => 'required',
			'state' => 'required',
			'city' => 'required',
			'birth_date' => 'required',
		], $messages);
		
		if ($validation->fails()) 
		{
			return Redirect::route('edit', $employee_id)
			->withInput()
			->withErrors($validation)
			->with('message', 'There were validation errors.');
		}
		else
		{
			Employee::where('id',$employee_id)->update([
				'name' => $request->input('name'),
				'email' => $request->input('email'),
				'mobile_number' => $request->input('mobile_number'),
				'country' => $request->input('country'),
				'state' => $request->input('state'),
				'city' => $request->input('city'),
				'birth_date' => $request->input('birth_date'),
				'updated_at' => date('Y-m-d H:i:s'),
			]);
			
			session()->flash('successmsg','Employee Updated Successfully.');
			return Redirect::route('lists');
		}
	}
}		