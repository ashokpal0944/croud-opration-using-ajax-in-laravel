<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
		<div class="col-md-8 col-md-offset-2">
				<input type="hidden" name="employee_id" id="employee_id" value="<?php echo e($get_employee->id); ?>">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<h5> Name <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="name" id="name" value="<?php echo e($get_employee->name); ?>" required required data-validation-required-message="This field is required"> </div>
							<?php if($errors->has('name')): ?>
							<span class="validation" style="color:red;">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5>User Email <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="email" name="email" id="email" class="form-control" value="<?php echo e($get_employee->email); ?>" data-validation-required-message="This field is required" required> </div>
							<?php if($errors->has('email')): ?>
							<span class="validation" style="color:red;">
								<strong><?php echo e($errors->first('email')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5>Mobile Number <span class="text-danger">*</span></h5>
							<div class="controls">
								<div class="input-group">
								<input type="text" class="form-control" name="mobile_number" id="mobile_number" placeholder="" value="<?php echo e($get_employee->mobile_number); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10"  required data-validation-required-message="This field is required"></div>
								<?php if($errors->has('mobile_number')): ?>
								<span class="validation" style="color:red;">
									<strong><?php echo e($errors->first('mobile_number')); ?></strong>
								</span>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5> Country <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="country" id="country" value="<?php echo e($get_employee->country); ?>" required required data-validation-required-message="This field is required"> </div>
							<?php if($errors->has('country')): ?>
							<span class="validation" style="color:red;">
								<strong><?php echo e($errors->first('country')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<h5> State <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="state" id="state" value="<?php echo e($get_employee->state); ?>" required required data-validation-required-message="This field is required"> </div>
							<?php if($errors->has('state')): ?>
							<span class="validation" style="color:red;">
								<strong><?php echo e($errors->first('state')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<h5> City <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="text"  class="form-control" name="city" id="city" value="<?php echo e($get_employee->city); ?>" required required data-validation-required-message="This field is required"> </div>
							<?php if($errors->has('city')): ?>
							<span class="validation" style="color:red;">
								<strong><?php echo e($errors->first('city')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<h5> Birth Date <span class="text-danger">*</span></h5>
							<div class="controls">
							<input type="date"  class="form-control" name="birth_date" id="birth_date" value="<?php echo e($get_employee->birth_date); ?>" required required data-validation-required-message="This field is required"> </div>
							<?php if($errors->has('birth_date')): ?>
							<span class="validation" style="color:red;">
								<strong><?php echo e($errors->first('birth_date')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					
				</div>
				<div class="text-xs-right">
					<button type="button" class="btn btn-info" onclick="updateEmployee();">Submit</button>
					<a href="javascript:history.go(-1)" class="btn btn-default">Cancel</a>
				</div>
		</div>
	</div>
	<!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
	function updateEmployee()
	{
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
		
        var name = $('#name').val();
        var email = $('#email').val();
        var mobile_number = $('#mobile_number').val();
        var country = $('#country').val();
        var state = $('#state').val();
        var city = $('#city').val();
        var employee_id = $('#employee_id').val();
        var birth_date = $('#birth_date').val();
    
		$.ajax({  
			url:"<?php echo e(url('update-data')); ?>",
			method:"POST",  
			data:{name:name,email:email,mobile_number:mobile_number,country:country,state:state,city:city,employee_id:employee_id,birth_date:birth_date},
			success: function( data ) {
			
				window.location.href="<?php echo e(url('lists')); ?>" ;
			}
		}); 
	} 
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>