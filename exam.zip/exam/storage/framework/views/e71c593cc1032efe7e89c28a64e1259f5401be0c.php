<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div style="float:right;">
				<a href="<?php echo e(route('add')); ?>" id="add" class="btn btn-primary">Add Employee</a></br/>
			</div></br>
			<div>
				<input type="date" name="from_date" id="from_date"> From Date
				&nbsp&nbsp
				<input type="date" name="to_date" id="to_date"> To Date
			</div></br>
			<table id="tasklistdata" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Name</th>
						<th>Email</th>
						<th>Mobile Number</th>
						<th>Country</th>
						<th>State</th>
						<th>City</th>
						<th>Birth Date</th>
						<th>Action</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
		<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
		<script>
			$(document).ready(function()
			{ 
				$.ajaxSetup({
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					}
				});
				
				var dataTable = $('#tasklistdata').DataTable({
					processing:true,
					"language": {
						'loadingRecords': '&nbsp;',
						'processing': 'Loading...'
					},
					serverSide:true, 
					bLengthChange: true,
					bFilter: true,
					bInfo: true,
					iDisplayLength: 25,
					order: [[0, 'desc'] ],
					bAutoWidth: false,			 
					"ajax":{
						"url": "<?php echo e(url('listingEmployee')); ?>",
						"dataType": "json",
						"type": "POST",
						"data": function (d) {
							d._token   = "<?php echo e(csrf_token()); ?>";
							d.search   = $('input[type="search"]').val();
							d.status   = $('select[name="status"]').val();
							d.from_date   = $("#from_date").val();
							d.to_date   = $("#to_date").val();
						}
					},
					"columns": [
					{ "data": "name" },
					{ "data": "email" },
					{ "data": "mobile_number" },
					{ "data": "country" },
					{ "data": "state" },
					{ "data": "city" },
					{ "data": "birth_date" },
					{ "data": "action" }
					]	 
				});
				
				$(".search-input-text").keyup(function(){
					dataTable.draw();
				});
				$('#status').on("change", function (event) {
					dataTable.draw();
					event.preventDefault();
				});
				
				$('#to_date').on("change", function (event) {
					dataTable.draw();
					event.preventDefault();
				});
			});
			function confirm_click(id) {
				var _token = $('input[name="_token"]').val();
				
				$.ajax({
					url:"<?php echo e(url('delete_rmployee')); ?>",
					method:"POST",
					data:{id:id, _token:_token},
					success:function(result)
					{
						location.reload();
					}
				})
			}
			$(function($){
				$('body').tooltip({
					selector: '[rel=tooltip]'
				});
			});
		</script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>