<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class EditEmployeesTable080520210248 extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employees', function (Blueprint $table) {
			$table->string('name')->after('id');
			$table->string('email')->after('name');
			$table->string('password')->after('email');
			$table->string('mobile_number')->after('password');
			$table->string('country')->after('city');
			$table->string('state')->after('country');
            $table->string('city')->after('state');
            $table->string('birth_date')->nullable()->after('city');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employees', function (Blueprint $table) {
            //
        });
    }
}
